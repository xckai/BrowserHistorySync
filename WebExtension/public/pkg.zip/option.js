var dataServerUrlInputElement = (document.getElementById("data_server_url_input"));
var equipmentNameInputElement = (document.getElementById("equipment_name"));
var delayUploadTimeInputElement = (document.getElementById("delay_upload_time"));
var repalceNewTabInputElement = (document.getElementById("replace_new_opened_tab"));
repalceNewTabInputElement.onchange = function () {
    browser.storage.local
        .set({
        replaceNewTab: repalceNewTabInputElement.checked,
    })
        .catch(function (e) { return console.error(e); });
};
var password = document.getElementById("password");
function onSave(e) {
    e.stopImmediatePropagation();
    e.preventDefault();
    if (!dataServerUrlInputElement.value) {
        alert("Please input server url");
        return;
    }
    if (!equipmentNameInputElement.value) {
        alert("Please input equipment name");
    }
    var dataServerUrl = dataServerUrlInputElement.value.endsWith("/")
        ? dataServerUrlInputElement.value.substring(0, dataServerUrlInputElement.value.length - 1)
        : dataServerUrlInputElement.value;
    browser.storage.local
        .set({
        dataServerUrl: dataServerUrl,
        fontendServerUrl: dataServerUrl,
        equipmentName: equipmentNameInputElement.value,
        delayUploadTime: delayUploadTimeInputElement.value,
    })
        .then(function () {
        fetch(dataServerUrl + "/api/Auth/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: "secret=".concat(password.value),
        })
            .then(function (resp) {
            if (!resp.ok) {
                resp
                    .text()
                    .then(function (str) {
                    return str ? alert(str) : alert("Response status code: " + resp.status);
                })
                    .catch(function (err) { return alert("Response status code: " + resp.status); });
            }
            else {
                browser.runtime.sendMessage({ type: "normal", action: "setIcon" });
                setTimeout(window.close, 500);
            }
        })
            .catch(function (err) {
            console.log(err);
        });
    })
        .catch(function (e) {
        console.error(e);
        alert("Save to storage error!");
    });
}
window.onload = function () {
    browser.storage.local
        .get([
        "dataServerUrl",
        "equipmentName",
        "fontendServerUrl",
        "delayUploadTime",
        "replaceNewTab",
    ])
        .then(function (res) {
        var _a;
        if (res["equipmentName"]) {
            equipmentNameInputElement.value = res["equipmentName"];
        }
        else {
            var equipmentName = "New_" + Math.round(Math.random() * 10000);
            equipmentNameInputElement.value = equipmentName;
            browser.storage.local
                .set({
                equipmentName: equipmentName,
            })
                .catch(function (e) { return console.error(e); });
        }
        if (res["delayUploadTime"]) {
            delayUploadTimeInputElement.value = res["delayUploadTime"];
        }
        if (res["dataServerUrl"]) {
            dataServerUrlInputElement.value = res["dataServerUrl"];
        }
        else {
            dataServerUrlInputElement.value = "https://";
        }
        repalceNewTabInputElement.checked = (_a = res["replaceNewTab"]) !== null && _a !== void 0 ? _a : false;
        console.log(res);
    });
};
document.getElementById("save_button").addEventListener("click", onSave);
