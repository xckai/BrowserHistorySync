function onSave() {
    var dataServerUrlInputElement = document.getElementById("data_server_url_input");
    var fontendServerUrlInputElement = document.getElementById("fontend_server_url_input");
    var equipmentNameInputElement = document.getElementById("equipment_name");
    browser.storage.local.set({
        dataServerUrl: dataServerUrlInputElement.value,
        fontendServerUrl: fontendServerUrlInputElement.value,
        equipmentName: equipmentNameInputElement.value
    }).then(function () {
        window.close();
    }).catch(function (e) { return console.error(e); });
}
browser.storage.local.get(["dataServerUrl", "equipmentName", "fontendServerUrl"]).then(function (res) {
    var _a, _b;
    var dataServerUrlInputElement = document.getElementById("data_server_url_input");
    dataServerUrlInputElement.value = (_a = res["dataServerUrl"]) !== null && _a !== void 0 ? _a : "https://";
    var fontendServerUrlInputElement = document.getElementById("fontend_server_url_input");
    fontendServerUrlInputElement.value = (_b = res["fontendServerUrl"]) !== null && _b !== void 0 ? _b : "https://";
    var equipmentNameInputElement = document.getElementById("equipment_name");
    if (res["equipmentName"]) {
        equipmentNameInputElement.value = res["equipmentName"];
    }
    else {
        var equipmentName = "New_" + Math.round(Math.random() * 10000);
        equipmentNameInputElement.value = equipmentName;
        browser.storage.local.set({
            equipmentName: equipmentName
        }).catch(function (e) { return console.error(e); });
    }
});
document.getElementById("save_button").addEventListener("click", onSave);
