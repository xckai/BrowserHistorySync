var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
define("lib/syncStrategy/timerBasedSyncByAlarm", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TimerBasedSyncByAlarm = void 0;
    var TimerBasedSyncByAlarm = /** @class */ (function () {
        function TimerBasedSyncByAlarm() {
        }
        TimerBasedSyncByAlarm.prototype.distory = function () {
            browser.tabs.onUpdated.removeListener(this.onUrlChange.bind(this));
        };
        TimerBasedSyncByAlarm.prototype.onUrlChange = function (tabId, changeInfo) {
            return __awaiter(this, void 0, void 0, function () {
                var url, handling, recoders;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            url = changeInfo.url;
                            if (!url) {
                                return [2 /*return*/];
                            }
                            handling = [];
                            return [4 /*yield*/, browser.storage.local.get(["timeBasedHistoryRecoders"])];
                        case 1:
                            recoders = (_a.sent()).timeBasedHistoryRecoders;
                            recoders = recoders !== null && recoders !== void 0 ? recoders : [];
                            recoders = recoders.filter(function (recoder) {
                                if (Date.now() - recoder.timestamp > 30000) {
                                    handling.push(recoder);
                                    return false;
                                }
                                else if (tabId == recoder.tabId) {
                                    return false;
                                }
                                return true;
                            });
                            recoders.push({ url: url, timestamp: Date.now(), tabId: tabId });
                            return [4 /*yield*/, browser.storage.local.set({
                                    timeBasedHistoryRecoders: recoders
                                })];
                        case 2:
                            _a.sent();
                            console.log(recoders, handling, "recoders");
                            handling.length > 0 && this.handleRecoders(handling);
                            return [4 /*yield*/, browser.alarms.create("timerbasedSyncTimer", { delayInMinutes: 1 })];
                        case 3:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        TimerBasedSyncByAlarm.prototype.config = function (callback) {
            var _this = this;
            this._batchSyncCallback = callback;
            browser.tabs.onUpdated.addListener(this.onUrlChange.bind(this));
            browser.alarms.onAlarm.addListener(function (alarm) {
                _this.checkRecoderByTimer(alarm);
            });
        };
        TimerBasedSyncByAlarm.prototype.checkRecoderByTimer = function (alarm) {
            return __awaiter(this, void 0, void 0, function () {
                var recoders, handling, _a;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            console.log("checked by timer", alarm);
                            if (alarm == undefined || alarm.name !== "timerbasedSyncTimer") {
                                return [2 /*return*/];
                            }
                            return [4 /*yield*/, browser.storage.local.get(["timeBasedHistoryRecoders"])];
                        case 1:
                            recoders = (_b.sent()).timeBasedHistoryRecoders;
                            recoders = recoders !== null && recoders !== void 0 ? recoders : [];
                            handling = [];
                            recoders = recoders.filter(function (recoder) {
                                if (Date.now() - recoder.timestamp > 30000) {
                                    handling.push(recoder);
                                    return false;
                                }
                                return true;
                            });
                            return [4 /*yield*/, browser.storage.local.set({
                                    timeBasedHistoryRecoders: recoders
                                })];
                        case 2:
                            _b.sent();
                            _a = handling.length > 0;
                            if (!_a) return [3 /*break*/, 4];
                            return [4 /*yield*/, this.handleRecoders(handling)];
                        case 3:
                            _a = (_b.sent());
                            _b.label = 4;
                        case 4:
                            _a;
                            if (!(recoders.length > 0)) return [3 /*break*/, 6];
                            return [4 /*yield*/, browser.alarms.create("timerbasedSyncTimer", { delayInMinutes: 1 })];
                        case 5:
                            _b.sent();
                            _b.label = 6;
                        case 6: return [2 /*return*/];
                    }
                });
            });
        };
        TimerBasedSyncByAlarm.prototype.handleRecoders = function (recoders) {
            return __awaiter(this, void 0, void 0, function () {
                var tabs, urlInfos;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, Promise.all(recoders.map(function (recoder) { return __awaiter(_this, void 0, void 0, function () {
                                return __generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, browser.tabs.get(recoder.tabId).catch(function (err) {
                                                console.log("tab error: ", err);
                                            })];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); }))];
                        case 1:
                            tabs = _a.sent();
                            console.log(tabs);
                            urlInfos = tabs.filter(function (t) { return !!t; }).map(function (tab) { return ({
                                Url: tab.url,
                                Title: tab.title,
                                FaviconUrl: tab.favIconUrl,
                            }); });
                            if (urlInfos.length > 0) {
                                this._batchSyncCallback(urlInfos);
                            }
                            return [2 /*return*/];
                    }
                });
            });
        };
        return TimerBasedSyncByAlarm;
    }());
    exports.TimerBasedSyncByAlarm = TimerBasedSyncByAlarm;
});
define("lib/syncStrategy/timerBasedSyncByContentJS", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TimerBasedSyncByContentJS = void 0;
    var TimerBasedSyncByContentJS = /** @class */ (function () {
        function TimerBasedSyncByContentJS() {
        }
        TimerBasedSyncByContentJS.prototype.distory = function () {
            browser.runtime.onMessage.removeListener(this.onReceiveContextMsg.bind(this));
        };
        TimerBasedSyncByContentJS.prototype.config = function (callback) {
            this._batchSyncCallback = callback;
            browser.runtime.onMessage.addListener(this.onReceiveContextMsg.bind(this));
        };
        TimerBasedSyncByContentJS.prototype.onReceiveContextMsg = function (msg, sender, sendResponse) {
            return __awaiter(this, void 0, void 0, function () {
                var tab;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            console.log("receive msg", msg, sender);
                            if (!(msg.type == "TimerBasedSyncTrigger")) return [3 /*break*/, 2];
                            return [4 /*yield*/, browser.tabs.get(sender.tab.id)];
                        case 1:
                            tab = _a.sent();
                            if (tab) {
                                this._batchSyncCallback([
                                    {
                                        Url: tab.url,
                                        Title: tab.title,
                                        FaviconUrl: tab.favIconUrl,
                                    }
                                ]);
                            }
                            sendResponse(true);
                            _a.label = 2;
                        case 2:
                            sendResponse(false);
                            return [2 /*return*/, true];
                    }
                });
            });
        };
        return TimerBasedSyncByContentJS;
    }());
    exports.TimerBasedSyncByContentJS = TimerBasedSyncByContentJS;
});
define("lib/sender", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SendToRemote = exports.batchSyncWithRemoteServer = void 0;
    var sendingMessageQueue = [];
    var browserType = "Chrome";
    if ((navigator.userAgent.indexOf("Edg") != -1)) {
        browserType = "Edge";
    }
    function post(url, data) {
        if (url === void 0) { url = ''; }
        if (data === void 0) { data = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, fetch(url, {
                                method: 'POST',
                                mode: 'cors',
                                cache: 'no-cache',
                                credentials: 'same-origin',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                redirect: 'follow',
                                referrerPolicy: 'no-referrer',
                                body: JSON.stringify(data) // body data type must match "Content-Type" header
                            })];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 3];
                    case 2:
                        e_1 = _a.sent();
                        console.error(e_1);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/]; // parses JSON response into native JavaScript objects
                }
            });
        });
    }
    function batchSyncWithRemoteServer(urlInfos) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, dataServerUrl, equipmentName;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, browser.storage.local.get(["dataServerUrl", "equipmentName"])];
                    case 1:
                        _a = _b.sent(), dataServerUrl = _a.dataServerUrl, equipmentName = _a.equipmentName;
                        if (!dataServerUrl) {
                            console.error("Remote server URL is null!!");
                        }
                        console.log("upload: ", urlInfos, dataServerUrl);
                        return [4 /*yield*/, post(dataServerUrl + "/api/UrlHistory/BatchSyncUrlHistory", {
                                equipmentInfo: {
                                    equipmentName: equipmentName,
                                    browserType: browserType
                                },
                                historyList: urlInfos
                            })];
                    case 2:
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    }
    exports.batchSyncWithRemoteServer = batchSyncWithRemoteServer;
    function SendToRemote(urlInfo) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, dataServerUrl, equipmentName;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, browser.storage.local.get(["dataServerUrl", "equipmentName"])];
                    case 1:
                        _a = _b.sent(), dataServerUrl = _a.dataServerUrl, equipmentName = _a.equipmentName;
                        if (!dataServerUrl) {
                            console.error("Remote server URL is null!!");
                        }
                        console.log("upload: ", urlInfo, dataServerUrl);
                        return [4 /*yield*/, post(dataServerUrl, {
                                equipmentInfo: {
                                    equipmentName: equipmentName,
                                    browserType: browserType
                                },
                                historyList: [urlInfo]
                            })];
                    case 2:
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    }
    exports.SendToRemote = SendToRemote;
});
define("lib/syncManager", ["require", "exports", "lib/syncStrategy/timerBasedSyncByAlarm", "lib/syncStrategy/timerBasedSyncByContentJS", "lib/sender"], function (require, exports, timerBasedSyncByAlarm_1, timerBasedSyncByContentJS_1, sender_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.syncManager = void 0;
    var SyncManager = /** @class */ (function () {
        function SyncManager() {
        }
        SyncManager.prototype.useSyncStrategy = function (name) {
            switch (name) {
                case "TimerBasedSync":
                    this.updateStrategy(new timerBasedSyncByAlarm_1.TimerBasedSyncByAlarm());
                    break;
                case "TimerBasedSyncByContentJS":
                    this.updateStrategy(new timerBasedSyncByContentJS_1.TimerBasedSyncByContentJS());
                    break;
                default:
                    throw new Error("Error！ can not found sync strategy named: " + name);
            }
        };
        SyncManager.prototype.updateStrategy = function (stragyHandle) {
            if (this.currentSyncHandler) {
                this.currentSyncHandler.distory();
            }
            this.currentSyncHandler = stragyHandle;
            this.currentSyncHandler.config(function (urlInfos) {
                (0, sender_1.batchSyncWithRemoteServer)(urlInfos);
            });
        };
        return SyncManager;
    }());
    exports.syncManager = new SyncManager();
});
define("background", ["require", "exports", "lib/syncManager"], function (require, exports, syncManager_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    syncManager_1.syncManager.useSyncStrategy("TimerBasedSyncByContentJS");
});
requirejs(['background']);