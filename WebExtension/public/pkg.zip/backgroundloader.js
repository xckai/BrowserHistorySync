try {
  importScripts("common.js", "background.js");
} catch (e) {
  console.log(e);
}
